import { useState } from 'react';
import axios from 'axios';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { TextField, Button, CircularProgress } from '@mui/material';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

function TruckOperations() {
  const [formData, setFormData] = useState({ Date: '' });
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    setLoading(true);
    setError('');
    console.log('Fetching Truck Operations for date:', formData.Date);
    try {
      const res = await axios.get('http://localhost:5000/api/truck-operations', {
        params: { date: formData.Date }
      });
      console.log('Response:', res.data);
      const data = res.data.data;
      if (data.length === 0) {
        setError('No data found for the selected date.');
        setChartData(null);
        return;
      }

      const labels = data.map(item => `${item.Stockyard} (${item.BaggingPlant})` || 'Unknown');
      const totalBags = data.map(item => item.TotalBags || 0);
      const stockyardTime = data.map(item => item['StockyardTime(min)'] || 0);
      const queueTime = data.map(item => item['Queue Time(min)'] || 0);
      const fillingTime = data.map(item => item['FillingTime(min)'] || 0);

      setChartData({
        labels,
        datasets: [
          {
            label: 'Total Bags',
            data: totalBags,
            backgroundColor: 'rgba(0, 85, 102, 0.6)',
          },
          {
            label: 'Stockyard Time (min)',
            data: stockyardTime,
            backgroundColor: 'rgba(245, 166, 35, 0.6)',
          },
          {
            label: 'Queue Time (min)',
            data: queueTime,
            backgroundColor: 'rgba(100, 100, 100, 0.6)',
          },
          {
            label: 'Filling Time (min)',
            data: fillingTime,
            backgroundColor: 'rgba(34, 139, 34, 0.6)',
          }
        ]
      });
    } catch (err) {
      console.error('Fetch error:', err);
      setError('Failed to fetch data.');
      setChartData(null);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      title: { display: true, text: 'Truck Operations by Stockyard and Bagging Plant' }
    }
  };

  return (
    <div className="bg-mastek-white p-6 rounded-lg shadow-lg glassmorphism max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-mastek-blue mb-4">Truck Operations</h2>
      <div className="flex space-x-4 mb-4">
        <TextField
          label="Select Date"
          type="date"
          name="Date"
          value={formData.Date}
          onChange={handleChange}
          InputLabelProps={{ shrink: true }}
          className="flex-1"
        />
        <Button
          variant="contained"
          onClick={fetchData}
          disabled={loading || !formData.Date}
          style={{ backgroundColor: '#005566', color: '#FFFFFF' }}
        >
          Fetch Data
        </Button>
      </div>
      {loading && <CircularProgress className="mx-auto my-4" />}
      {error && <p className="text-red-500">{error}</p>}
      {chartData && (
        <div className="bg-white p-4 rounded-lg">
          <Bar options={options} data={chartData} />
        </div>
      )}
    </div>
  );
}

export default TruckOperations;