import { useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, LineElement, PointElement, Title, Tooltip, Legend } from 'chart.js';
import { TextField, Button, CircularProgress } from '@mui/material';

ChartJS.register(CategoryScale, LinearScale, LineElement, PointElement, Title, Tooltip, Legend);

function Forecast() {
  const [formData, setFormData] = useState({ Date: '' });
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchData = async () => {
    setLoading(true);
    setError('');
    console.log('Fetching Forecast for date:', formData.Date);
    try {
      const res = await axios.get('http://localhost:5000/api/forecast-plannings', {
        params: { date: formData.Date }
      });
      console.log('Response:', res.data);
      const data = res.data.data;
      if (data.length === 0) {
        setError('No data found for the selected date.');
        setChartData(null);
        return;
      }

      const labels = data.map(item => `${item.Stockyard} (${item.BaggingPlant})` || 'Unknown');
      const forecastTruckCount = data.map(item => item.ForecastTruckCount || 0);
      const expectedGrade1Bags = data.map(item => item.ExpectedGrade1Bags || 0);
      const expectedGrade2Bags = data.map(item => item.ExpectedGrade2Bags || 0);
      const maxCapacity = data.map(item => item.MaxCapacity || 0);

      setChartData({
        labels,
        datasets: [
          {
            label: 'Forecast Truck Count',
            data: forecastTruckCount,
            borderColor: '#005566',
            backgroundColor: 'rgba(0, 85, 102, 0.2)',
            fill: true,
          },
          {
            label: 'Expected Grade 1 Bags',
            data: expectedGrade1Bags,
            borderColor: '#F5A623',
            backgroundColor: 'rgba(245, 166, 35, 0.2)',
            fill: true,
          },
          {
            label: 'Expected Grade 2 Bags',
            data: expectedGrade2Bags,
            borderColor: '#666666',
            backgroundColor: 'rgba(100, 100, 100, 0.2)',
            fill: true,
          },
          {
            label: 'Max Capacity',
            data: maxCapacity,
            borderColor: '#228B22',
            backgroundColor: 'rgba(34, 139, 34, 0.2)',
            fill: true,
          }
        ]
      });
    } catch (err) {
      console.error('Fetch error:', err);
      setError('Failed to fetch data.');
      setChartData(null);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const options = {
    responsive: true,
    plugins: {
      legend: { position: 'top' },
      title: { display: true, text: 'Forecast Plannings by Stockyard and Bagging Plant' }
    }
  };

  return (
    <div className="bg-mastek-white p-6 rounded-lg shadow-lg glassmorphism max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-mastek-blue mb-4">Forecast Plannings</h2>
      <div className="flex space-x-4 mb-4">
        <TextField
          label="Select Date"
          type="date"
          name="Date"
          value={formData.Date}
          onChange={handleChange}
          InputLabelProps={{ shrink: true }}
          className="flex-1"
        />
        <Button
          variant="contained"
          onClick={fetchData}
          disabled={loading || !formData.Date}
          style={{ backgroundColor: '#005566', color: '#FFFFFF' }}
        >
          Fetch Data
        </Button>
      </div>
      {loading && <CircularProgress className="mx-auto my-4" />}
      {error && <p className="text-red-500">{error}</p>}
      {chartData && (
        <div className="bg-white p-4 rounded-lg">
          <Line options={options} data={chartData} />
        </div>
      )}
    </div>
  );
}

export default Forecast;