import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { useState } from 'react';
import AssetUtilization from './AssetUtilization';
import Forecast from './Forecast';
import StockyardDetails from './StockyardDetails';
import TruckOperations from './TruckOperations';
import WeatherPrediction from './WeatherPrediction';

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <BrowserRouter>
      <div className="flex min-h-screen bg-gray-100">
        <div className={`${isSidebarOpen ? 'w-64' : 'w-16'} bg-mastek-blue text-white flex flex-col shadow-lg transition-all duration-300`}>
          <div className="p-4 flex items-center justify-between">
            {isSidebarOpen && (
              <span className="text-2xl font-bold text-mastek-orange">Mastek</span>
            )}
            <button onClick={toggleSidebar} className="text-mastek-white hover:text-mastek-orange">
              {isSidebarOpen ? '◄' : '►'}
            </button>
          </div>
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              <li>
                <NavLink
                  to="/"
                  className={({ isActive }) => `flex items-center p-3 rounded-lg transition-colors ${isActive ? 'bg-mastek-orange text-mastek-blue' : 'hover:bg-mastek-gray/10'}`}
                  title="Asset Utilization"
                >
                  <span className="text-xl">📊</span>
                  {isSidebarOpen && <span className="ml-2">Asset Utilization</span>}
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/forecast"
                  className={({ isActive }) => `flex items-center p-3 rounded-lg transition-colors ${isActive ? 'bg-mastek-orange text-mastek-blue' : 'hover:bg-mastek-gray/10'}`}
                  title="Forecast"
                >
                  <span className="text-xl">📈</span>
                  {isSidebarOpen && <span className="ml-2">Forecast</span>}
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/stockyard"
                  className={({ isActive }) => `flex items-center p-3 rounded-lg transition-colors ${isActive ? 'bg-mastek-orange text-mastek-blue' : 'hover:bg-mastek-gray/10'}`}
                  title="Stockyard Details"
                >
                  <span className="text-xl">🏭</span>
                  {isSidebarOpen && <span className="ml-2">Stockyard Details</span>}
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/trucks"
                  className={({ isActive }) => `flex items-center p-3 rounded-lg transition-colors ${isActive ? 'bg-mastek-orange text-mastek-blue' : 'hover:bg-mastek-gray/10'}`}
                  title="Truck Operations"
                >
                  <span className="text-xl">🚛</span>
                  {isSidebarOpen && <span className="ml-2">Truck Operations</span>}
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/weather"
                  className={({ isActive }) => `flex items-center p-3 rounded-lg transition-colors ${isActive ? 'bg-mastek-orange text-mastek-blue' : 'hover:bg-mastek-gray/10'}`}
                  title="Weather Prediction"
                >
                  <span className="text-xl">🌤️</span>
                  {isSidebarOpen && <span className="ml-2">Weather Prediction</span>}
                </NavLink>
              </li>
            </ul>
          </nav>
        </div>
        <div className="flex-1 p-6 overflow-auto">
          <Routes>
            <Route path="/" element={<AssetUtilization />} />
            <Route path="/forecast" element={<Forecast />} />
            <Route path="/stockyard" element={<StockyardDetails />} />
            <Route path="/trucks" element={<TruckOperations />} />
            <Route path="/weather" element={<WeatherPrediction />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

const root = createRoot(document.getElementById('root'));
root.render(<App />);
export default App;