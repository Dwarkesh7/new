import { useState, useEffect } from 'react';
import axios from 'axios';
import { CircularProgress } from '@mui/material';

function WeatherPrediction() {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchWeather = async () => {
    setLoading(true);
    setError('');
    try {
      const latitude = 24.7136;
      const longitude = 46.6753;
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&hourly=visibility,precipitation,windspeed_10m`;
      const response = await axios.get(url);
      const data = response.data;
      const current = data.current_weather;
      const hourly = data.hourly;
      const latestHour = hourly.time.length - 1;

      let condition = 'Normal';
      const windspeed = hourly.windspeed_10m[latestHour];
      const visibility = hourly.visibility[latestHour];
      const precipitation = hourly.precipitation[latestHour];

      if (windspeed > 30 && visibility < 1000) {
        condition = 'Sandstorm';
      } else if (precipitation > 0) {
        condition = 'Rainy';
      }

      setWeather({
        temperature: current.temperature,
        windspeed: current.windspeed,
        winddirection: current.winddirection,
        time: current.time,
        condition,
        visibility: visibility,
        precipitation: precipitation
      });
    } catch (err) {
      console.error('Weather fetch error:', err);
      setError('Failed to fetch weather data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather();
  }, []);

  return (
    <div className="bg-mastek-white p-6 rounded-lg shadow-lg glassmorphism max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold text-mastek-blue mb-4">Weather in Riyadh</h2>
      {loading && <CircularProgress className="mx-auto my-4" />}
      {error && <p className="text-red-500">{error}</p>}
      {weather && (
        <div className="space-y-4">
          <p className="text-lg">As of {weather.time}:</p>
          <p className="text-lg">Condition: <span className={`font-bold ${weather.condition === 'Sandstorm' ? 'text-red-500' : weather.condition === 'Rainy' ? 'text-blue-500' : 'text-green-500'}`}>{weather.condition}</span></p>
          <p className="text-lg">Temperature: {weather.temperature}°C</p>
          <p className="text-lg">Wind Speed: {weather.windspeed} km/h</p>
          <p className="text-lg">Wind Direction: {weather.winddirection}°</p>
          <p className="text-lg">Visibility: {weather.visibility} m</p>
          <p className="text-lg">Precipitation: {weather.precipitation} mm</p>
        </div>
      )}
    </div>
  );
}

export default WeatherPrediction;