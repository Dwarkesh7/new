from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)

# MongoDB connection
mongo_uri = "mongodb+srv://abhilasha:EAg882TnIUzD0jqw@clusterforjobretail.h2tr0.mongodb.net/BaggingPlant?retryWrites=true&w=majority&appName=ClusterForJobRetail"
client = MongoClient(mongo_uri)
db = client['BaggingPlant']

# Helper function to create date query
def create_date_query(date_str, field_name):
    if not date_str:
        return {}
    try:
        # Parse input date (YYYY-MM-DD)
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        start_date = date_obj.replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = start_date + timedelta(days=1) - timedelta(microseconds=1)
        # Regex for string dates (e.g., "2025-05-01 00:00:00")
        date_pattern = f"^{date_str}"
        return {
            '$or': [
                {field_name: {'$gte': start_date, '$lte': end_date}},  # ISODate
                {field_name: {'$regex': date_pattern, '$options': 'i'}}  # String
            ]
        }
    except ValueError:
        print(f"Invalid date format: {date_str}")
        return {}

# API Endpoints
@app.route('/api/asset-utilization', methods=['GET'])
def get_asset_utilization():
    try:
        date = request.args.get('date')
        query = create_date_query(date, 'Date')
        data = list(db.assetutilizations.find(query, {'_id': 0}))
        print(f"Asset Utilization query: {query}, found {len(data)} records")
        return jsonify({'data': data})
    except Exception as e:
        print(f"Error fetching asset utilization: {str(e)}")
        return jsonify({'error': 'Server error'}), 500

@app.route('/api/forecast-plannings', methods=['GET'])
def get_forecast_plannings():
    try:
        date = request.args.get('date')
        query = create_date_query(date, 'Date')
        data = list(db.forecastplannings.find(query, {'_id': 0}))
        print(f"Forecast Plannings query: {query}, found {len(data)} records")
        return jsonify({'data': data})
    except Exception as e:
        print(f"Error fetching forecast plannings: {str(e)}")
        return jsonify({'error': 'Server error'}), 500

@app.route('/api/truck-operations', methods=['GET'])
def get_truck_operations():
    try:
        date = request.args.get('date')
        query = create_date_query(date, 'EntryTime')
        data = list(db.truckoperations.find(query, {'_id': 0}))
        print(f"Truck Operations query: {query}, found {len(data)} records")
        return jsonify({'data': data})
    except Exception as e:
        print(f"Error fetching truck operations: {str(e)}")
        return jsonify({'error': 'Server error'}), 500

@app.route('/api/stockyard-details', methods=['GET'])
def get_stockyard_details():
    try:
        date = request.args.get('date')
        query = create_date_query(date, 'Date')
        data = list(db.stockyardDetails.find(query, {'_id': 0}))
        print(f"Stockyard Details query: {query}, found {len(data)} records")
        if len(data) == 0:
            print(f"No data found for date: {date}, collection: stockyardDetails")
        return jsonify({'data': data})
    except Exception as e:
        print(f"Error fetching stockyard details: {str(e)}")
        return jsonify({'error': 'Server error'}), 500

@app.route('/api/weather', methods=['GET'])
def get_weather():
    try:
        import requests
        latitude = 24.7136
        longitude = 46.6753
        url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={latitude}&longitude={longitude}&current_weather=true"
            f"&hourly=visibility,precipitation,windspeed_10m"
        )
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            current = data.get("current_weather", {})
            hourly = data.get("hourly", {})

            weather = {
                'temperature': current.get('temperature'),
                'windspeed': current.get('windspeed'),
                'winddirection': current.get('winddirection'),
                'time': current.get('time'),
                'condition': 'Normal'
            }

            latest_hour = len(hourly.get('time', [])) - 1
            if latest_hour >= 0:
                windspeed = hourly.get('windspeed_10m', [])[latest_hour]
                visibility = hourly.get('visibility', [])[latest_hour]
                precipitation = hourly.get('precipitation', [])[latest_hour]
                if windspeed > 30 and visibility < 1000:
                    weather['condition'] = 'Sandstorm'
                elif precipitation > 0:
                    weather['condition'] = 'Rain'
                elif windspeed > 20:
                    weather['condition'] = 'Windy'

            return jsonify(weather)
        else:
            return jsonify({'error': 'Failed to fetch weather data'}), response.status_code
    except Exception as e:
        print(f"Weather fetch error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(port=5000, debug=True)