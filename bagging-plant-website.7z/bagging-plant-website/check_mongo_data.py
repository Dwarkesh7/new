from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb+srv://abhilasha:EAg882TnIUzD0jqw@clusterforjobretail.h2tr0.mongodb.net/BaggingPlant")
db = client['BaggingPlant']
print("Collections:", db.list_collection_names())
for collection in ['assetutilizations', 'forecastplannings', 'truckoperations', 'stockyardDetails']:
    print(f"\n{collection} count:", db[collection].count_documents({}))
    print(f"Sample from {collection}:")
    sample = db[collection].find_one({'Date': {'$regex': '^2025-05-01'}}) or \
            db[collection].find_one({'EntryTime': {'$regex': '^2025-05-01'}}) or \
            db[collection].find_one()
    if sample:
        print(f"Sample document: {sample}")
        print(f"Date field: {sample.get('Date') or sample.get('EntryTime')}")
    else:
        print("No documents found")