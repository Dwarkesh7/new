module.exports = {
    content: ['./public/**/*.{html,js,jsx}', './src/**/*.{js,jsx}'],
    theme: {
      extend: {
        colors: {
          'mastek-blue': '#005566',
          'mastek-orange': '#F5A623',
          'mastek-white': '#FFFFFF',
          'mastek-gray': '#E8ECEF'
        }
      }
    },
    plugins: []
  };