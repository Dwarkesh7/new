from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb+srv://abhilasha:EAg882TnIUzD0jqw@clusterforjobretail.h2tr0.mongodb.net/BaggingPlant")
db = client['BaggingPlant']

# Clear existing data for 2025-05-01
date_start = datetime(2025, 5, 1)
date_end = datetime(2025, 5, 1, 23, 59, 59, 999999)
db.assetUtilization.delete_many({'Date': {'$gte': date_start, '$lte': date_end}})
db.forecastplannings.delete_many({'Date': {'$gte': date_start, '$lte': date_end}})
db.truckoperations.delete_many({'EntryTime': {'$gte': date_start, '$lte': date_end}})
db.stockyardDetails.delete_many({'Date': {'$gte': date_start, '$lte': date_end}})

# Insert assetUtilization
db.assetUtilization.insert_many([
    {
        "Date": datetime(2025, 5, 1),
        "BaggingPlant": "BG01SY1",
        "TrucksHandled": 20,
        "MaxTruckCapacity": 18,
        "OverloadFlag": "Yes",
        "Utilization": 1.5,
        "Reason": "No Issue"
    },
    {
        "Date": datetime(2025, 5, 1),
        "BaggingPlant": "BG02SY2",
        "TrucksHandled": 22,
        "MaxTruckCapacity": 20,
        "OverloadFlag": "No",
        "Utilization": 1.1,
        "Reason": "Normal"
    }
])

# Insert forecastplannings
db.forecastplannings.insert_many([
    {
        "Date": datetime(2025, 5, 1),
        "Stockyard": "SY3",
        "BaggingPlant": "BG02",
        "ForecastTruckCount": 30,
        "ExpectedGrade1Bags": 4200,
        "ExpectedGrade2Bags": 2300,
        "MaxCapacity": 6500,
        "NeedMoreAssets": "No"
    }
])

# Insert truckoperations
db.truckoperations.insert_many([
    {
        "TruckID": "TID97716",
        "Stockyard": "SY2",
        "BaggingPlant": "BG04SY2",
        "EntryTime": datetime(2025, 5, 1),
        "TotalBags": 520,
        "RequestType": "Grade1",
        "Grade1Bags": 520,
        "Grade2Bags": 0,
        "Grade3Bags": 0,
        "WeightPerBag(kg)": 50,
        "StockyardTime(min)": 180,
        "Queue Time(min)": 140,
        "FillingTime(min)": 25,
        "DayType": "Peak",
        "Weather": "Clear"
    },
    {
        "TruckID": "TID66215",
        "Stockyard": "SY3",
        "BaggingPlant": "BG02SY3",
        "EntryTime": datetime(2025, 5, 1),
        "TotalBags": 550,
        "RequestType": "Grade2",
        "Grade1Bags": 0,
        "Grade2Bags": 550,
        "Grade3Bags": 0,
        "WeightPerBag(kg)": 45,
        "StockyardTime(min)": 230,
        "Queue Time(min)": 175,
        "FillingTime(min)": 28,
        "DayType": "Peak",
        "Weather": "Clear"
    }
])

# Insert stockyardDetails
db.stockyardDetails.insert_many([
    {
        "Date": datetime(2025, 5, 1),
        "Stockyard": "SY1",
        "TotalBags": 1200,
        "UtilizationPercentage": 80
    },
    {
        "Date": datetime(2025, 5, 1),
        "Stockyard": "SY2",
        "TotalBags": 1100,
        "UtilizationPercentage": 70
    }
])

print("Test data inserted for 2025-05-01")